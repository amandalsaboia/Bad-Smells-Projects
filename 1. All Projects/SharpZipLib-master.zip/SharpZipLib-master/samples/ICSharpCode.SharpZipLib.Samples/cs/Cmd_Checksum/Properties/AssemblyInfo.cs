using System.Reflection;

[assembly: AssemblyTitle("Cmd_Checksum")]
[assembly: AssemblyDescription("file checksum generator")]
[assembly: AssemblyCulture("")]
