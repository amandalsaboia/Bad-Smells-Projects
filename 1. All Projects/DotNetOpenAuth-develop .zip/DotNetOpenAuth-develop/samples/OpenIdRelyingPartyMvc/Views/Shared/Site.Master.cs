﻿namespace OpenIdRelyingPartyMvc.Views.Shared {
	public partial class Site : System.Web.Mvc.ViewMasterPage {
	}
}
