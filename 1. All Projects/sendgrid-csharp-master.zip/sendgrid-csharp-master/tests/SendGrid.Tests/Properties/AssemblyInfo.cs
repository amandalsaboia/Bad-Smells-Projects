﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("Twilio SendGrid")]
[assembly: AssemblyProduct("SendGrid.Tests")]
[assembly: AssemblyTrademark("Twilio SendGrid")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d89adaea-2be8-49ac-b5bc-6eabbb2ae4e3")]
