## 说明

此文件夹为 Release 编译配置下的输出文件夹，包括所有版本的 dll、xml、pdb 及 Nuget 包等文件。

您下载本项目源代码，开启 [/Samples](../../Samples) 文件夹中的解决方案，并使用 Release 模式编译后，上述 dll、xml 等文件将会生成到这里。

通常情况下我们建议您直接使用我们已经编译并发布的正式版 dll：https://www.nuget.org/packages?q=Senparc.Weixin 。
