Senparc.Weixin.MP.P2PSDK
================

~~Senparc.Weixin.MP.P2P API已经开放公测，C#版本的SDK和测试工具也已全部开源。~~


~~P2P开放平台（代号：Souidea）地址：http://www.souidea.com~~

~~API文档：http://www.souidea.com/ApiDocuments~~

~~P2P SDK开源项目：https://github.com/JeffreySu/WeixinMPSDK.P2PSDK~~

------------------
（此页面自2013年10月30日起不再更新，更多详情请见：https://github.com/JeffreySu/WeixinMPSDK.P2PSDK ）
