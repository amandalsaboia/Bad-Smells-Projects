## 迁移说明

为将 Demo（Sample） 代码与 SDK 源文件（src）代码进行隔离，现已将当前目录迁移至 [/Samples/Senparc.Weixin.MP.Sample/](../../Samples/Senparc.Weixin.MP.Sample/)目录下，内容结构完全一致。