﻿## ByFilter 文件夹说明

BaseGroupMessageDataByFilter 为所有此文件夹下其他类的基类，用于提供具有筛选条件群发（GroupId、TagId）数据的基类