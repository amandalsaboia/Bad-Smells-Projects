﻿1、微信支付的示例代码请见：\Samples\Senparc.Weixin.MP.Sample\Senparc.Weixin.MP.Sample\Controllers\TenPayV3Controller.cs 及相关View
2、本示例主要提供 WebForms 对于 MessageHandler 等处理的演示（\Samples\Senparc.Weixin.MP.Sample\Senparc.Weixin.MP.Sample\），MVC 的 Demo 具有更加完整的演示，其他 Demo 请参考 MVC 项目。
3、项目的初始化需要在 global.asax 中进行一些设置，请参考 \Samples\Senparc.Weixin.MP.Sample\Senparc.Weixin.MP.Sample\global.asax.cs 对应文件。