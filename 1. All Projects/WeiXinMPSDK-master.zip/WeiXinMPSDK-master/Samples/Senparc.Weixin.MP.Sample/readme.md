# Senparc.Weixin.MP.Sample 项目说明

本项目为 .NET Framework 4.5 的 Demo，可以直接编译并发布运行。

> 注意： .NET Framework 4.5 Sample 将于 2019 年 9 月 1 日起停止小版本更新（大版本更新仍将保持同步，.NET 4.0/4.5 所有库更新不受影响）。

## .NET Core 及所有版本 Demo

返回上一级后见目录：[Senparc.Weixin.MP.Sample.vs2017](../Senparc.Weixin.MP.Sample.vs2017)。


## 其他说明

Senparc.Weixin.MP.Sample.CommonService 里面包含了CustomMessageHandler及原Senparc.Weixin.MP.Sample/Service目录的代码。

分离这些文件是为了在 WebForms 项目中重用。
