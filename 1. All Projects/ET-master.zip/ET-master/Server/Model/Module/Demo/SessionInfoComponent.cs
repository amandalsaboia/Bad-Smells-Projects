﻿namespace ETModel
{
	public class SessionInfoComponent : Component
	{
		public Session Session;
	}
}