﻿namespace ETModel
{
	public abstract class DBTask : ComponentWithId
	{
		public abstract ETTask Run();
	}
}