﻿using System.Net;

namespace ETModel
{
	public class LocationProxyComponent : Component
	{
		public IPEndPoint LocationAddress;
	}
}