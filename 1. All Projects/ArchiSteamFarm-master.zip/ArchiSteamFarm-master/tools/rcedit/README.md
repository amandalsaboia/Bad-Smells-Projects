rcedit
===================

**[Latest release](https://github.com/electron/rcedit/releases/latest)**

**[Source](https://github.com/electron/rcedit)**

---

This tool is being used by our CI for injecting ASF icon into Windows dotnet binary, until https://github.com/dotnet/cli/issues/3267 is eventually dealt with.
