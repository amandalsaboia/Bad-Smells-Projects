# NetHookAnalyzer2

This tool can be used for analyzing Steam network log, recorded either by NetHook2 hooked into official Steam Client, or ASF in `Debug` mode.

---

## Disclaimer

Source of files included in this directory can be found **[here](https://github.com/SteamRE/SteamKit/tree/master/Resources/NetHookAnalyzer2)**. The binary itself comes directly from SteamKit2's **[CI](https://ci.appveyor.com/project/SteamRE/SteamKit)**.
