<!--
I fully read and understood contributing guidelines of ASF available under https://github.com/JustArchiNET/ArchiSteamFarm/blob/master/.github/CONTRIBUTING.md and I believe that my issue is valid - it requires a response from ASF development team, and not ASF support.

I understand that if my issue is not meeting contributing guidelines specified above, especially if it's a question or technical issue that is not related to ASF development in any way, then it will be closed and left unanswered.

Feel free to remove our notice and fill the template below with your details.
-->

## Other

<!--
You're about to open a generic issue that isn't available as one of our issue templates. In most cases this is invalid and will be closed immediately - please ensure that your issue is really related to ASF development prior to posting it.
-->
