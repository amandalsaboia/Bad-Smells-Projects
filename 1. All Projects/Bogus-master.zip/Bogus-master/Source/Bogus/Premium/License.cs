﻿namespace Bogus.Premium
{
   public class License
   {
      public static string LicenseTo { get; set; }
      public static string LicenseKey { get; set; }
   }
}