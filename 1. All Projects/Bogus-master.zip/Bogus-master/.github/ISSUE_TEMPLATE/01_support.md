---
name: ❓ Support
labels: question
about: If you need help using Bogus 🏥
---

### Version Information
| Software                       | Version(s) |
| ------------------------| ---------- |
| Bogus NuGet Package  |                 |
| .NET Core?                   |                 |
| .NET Full Framework?   |                 |
| Windows OS?              |                  |
| Linux OS?                    |                  |
| Visual Studio?              |                  |

### What locale are you using with Bogus?

### What's the problem?

### What possible solutions have you considered?

### Do you have sample code to show what you're trying to do?

_(Please be complete. Include any class models necessary to run your code.)_